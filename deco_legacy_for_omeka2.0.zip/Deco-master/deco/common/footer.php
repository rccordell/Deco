</div><!-- end content -->

<div id="footer">

    <p>&copy; <?php echo date(Y);?> <?php echo html_escape(option('author'));?>
    <br/>Proudly powered by <a href="http://omeka.org">Omeka</a><?php echo deco_display_theme_credit();?></p>

    <br/><ul class="navigation">
		<?php echo public_nav_main();?>
    </ul>
	
</div><!-- end footer -->
</div><!-- end wrap -->
</body>

</html>