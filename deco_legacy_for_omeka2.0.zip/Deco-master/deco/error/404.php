<?php head(array('title'=>'404','bodyid'=>'404')); ?>

<div id="primary">
	
<h2>Oops!</h2>
	
	<p>Sorry, this page doesn't exist. Check your URL, or send us a note.</p>

</div><!-- end primary -->

<?php foot(); ?>
