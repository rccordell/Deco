Deco theme files:

deco -- general use theme for Omeka